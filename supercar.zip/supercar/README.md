# Supercar Elite - Site Web de Vente de Supercars

## Description
Site web dynamique pour la vente de supercars de luxe avec système d'authentification, catalogue de voitures, demandes d'essai, services et contact.

## Structure du Projet

### Frontend
- `index.html` - Page principale avec toutes les sections
- `styles.css` - Styles CSS avec animations et design responsive
- `script.js` - JavaScript pour l'interactivité et les appels API

### Backend (PHP + MySQL)
```
api/
├── config/
│   └── database.php          # Configuration base de données et fonctions utilitaires
├── auth/
│   ├── register.php          # Inscription utilisateur
│   ├── login.php             # Connexion utilisateur
│   ├── logout.php            # Déconnexion
│   └── check_session.php     # Vérification session
├── cars/
│   ├── get_cars.php          # Liste des voitures avec pagination/filtres
│   └── get_car_details.php   # Détails d'une voiture
├── services/
│   └── get_services.php      # Liste des services
├── bookings/
│   ├── create_booking.php    # Créer demande d'essai
│   └── get_user_bookings.php # Réservations utilisateur
└── contact/
    ├── send_message.php      # Envoyer message contact
    └── get_messages.php      # Lister messages (admin)
```

## Installation

### 1. Configuration WAMP
1. Démarrer WAMP Server
2. Placer les fichiers dans `C:\wamp64\www\supercar-elite\`

### 2. Base de Données
1. Ouvrir phpMyAdmin (http://localhost/phpmyadmin)
2. Importer le fichier `database.sql`
3. Ou exécuter les requêtes SQL manuellement

### 3. Configuration
Modifier `api/config/database.php` si nécessaire :
```php
$host = 'localhost';
$dbname = 'supercar_elite';
$username = 'root';
$password = '';
```

### 4. Accès
- Site web : http://localhost/supercar-elite/
- phpMyAdmin : http://localhost/phpmyadmin

## Fonctionnalités

### Authentification
- Inscription avec validation
- Connexion sécurisée
- Gestion des sessions
- Hachage des mots de passe

### Catalogue Voitures
- 9 supercars avec détails complets
- Images haute qualité
- Spécifications techniques
- Prix et disponibilité

### Demandes d'Essai
- Réservation de créneaux
- Vérification de disponibilité
- Protection par authentification
- Historique des demandes

### Services
- 9 services premium
- Descriptions détaillées
- Tarification
- Catégorisation

### Contact
- Formulaire de contact
- Validation des données
- Stockage en base de données
- Interface d'administration

## Sécurité

### Mesures Implémentées
- Validation et sanitisation des données
- Protection contre l'injection SQL (PDO)
- Hachage des mots de passe (password_hash)
- Gestion sécurisée des sessions
- Headers CORS configurés
- Validation côté serveur

### Recommandations Production
- Utiliser HTTPS
- Configurer un serveur mail pour les notifications
- Ajouter un système de logs
- Implémenter la limitation de taux (rate limiting)
- Ajouter une interface d'administration

## API Endpoints

### Authentification
- `POST /api/auth/register.php` - Inscription
- `POST /api/auth/login.php` - Connexion
- `POST /api/auth/logout.php` - Déconnexion
- `GET /api/auth/check_session.php` - Vérifier session

### Voitures
- `GET /api/cars/get_cars.php` - Liste voitures
- `GET /api/cars/get_car_details.php?id=X` - Détails voiture

### Services
- `GET /api/services/get_services.php` - Liste services

### Réservations
- `POST /api/bookings/create_booking.php` - Créer demande
- `GET /api/bookings/get_user_bookings.php` - Mes réservations

### Contact
- `POST /api/contact/send_message.php` - Envoyer message
- `GET /api/contact/get_messages.php` - Lister messages (admin)

## Technologies Utilisées

### Frontend
- HTML5 sémantique
- CSS3 avec animations et transitions
- JavaScript ES6+ (Vanilla)
- Font Awesome pour les icônes
- Google Fonts (Montserrat)

### Backend
- PHP 7.4+
- MySQL 5.7+
- PDO pour la base de données
- Sessions PHP pour l'authentification

## Support Navigateurs
- Chrome 80+
- Firefox 75+
- Safari 13+
- Edge 80+

## Développement

### Structure CSS
- Variables CSS pour la cohérence
- Système de grille responsive
- Animations et micro-interactions
- Design mobile-first

### JavaScript
- Architecture modulaire
- Gestion d'état simple
- Appels API asynchrones
- Validation côté client

## Maintenance

### Logs à Surveiller
- Erreurs PHP dans les logs Apache
- Tentatives de connexion échouées
- Messages d'erreur JavaScript (console)

### Sauvegardes
- Base de données MySQL
- Fichiers uploadés (si ajoutés)
- Configuration

## Contact Développeur
Pour toute question technique ou amélioration, contactez l'équipe de développement.